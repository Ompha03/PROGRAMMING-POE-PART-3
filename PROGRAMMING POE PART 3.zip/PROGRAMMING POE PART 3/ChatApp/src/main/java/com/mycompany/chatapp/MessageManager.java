package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Part 3: holds every message in arrays and supports the "Stored Messages"
 * features (display, longest, search, delete, report).
 *
 * The five required arrays are sentMessages, disregardedMessages,
 * storedMessages, messageHashes and messageIDs. The remaining lists are
 * parallel arrays: index i in each of messageIDs, messageHashes, recipients,
 * allMessages and flags describes the same message.
 */
public class MessageManager {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    // Required arrays (no hard-coded contents, filled while the app runs)
    private final ArrayList<String> sentMessages = new ArrayList<>();
    private final ArrayList<String> disregardedMessages = new ArrayList<>();
    private final ArrayList<String> storedMessages = new ArrayList<>();
    private final ArrayList<String> messageHashes = new ArrayList<>();
    private final ArrayList<String> messageIDs = new ArrayList<>();

    // Parallel arrays (same index = same message)
    private final ArrayList<String> recipients = new ArrayList<>();
    private final ArrayList<String> allMessages = new ArrayList<>();
    private final ArrayList<String> flags = new ArrayList<>();

    private final String sender;
    private final Random random = new Random();

    /** @param sender the logged-in user (shown as the sender in displays) */
    public MessageManager(String sender) {
        this.sender = sender;
    }

    // ------------------------------------------------------------------
    // Populating the arrays
    // ------------------------------------------------------------------

    /** Adds a message with an auto-generated ten-digit ID. Returns its hash. */
    public String addMessage(String recipient, String text, String flag) {
        return addMessage(generateMessageID(), recipient, text, flag);
    }

    /** Adds a message with a supplied ID; the hash is created here (used for test data). */
    public String addMessage(String id, String recipient, String text, String flag) {
        return addMessage(id, createMessageHash(id, messageIDs.size(), text), recipient, text, flag);
    }

    /**
     * Adds a message with a supplied ID and hash. ChatApp uses this so the hash
     * stored in the arrays is the same one the Message class showed the user.
     */
    public String addMessage(String id, String hash, String recipient, String text, String flag) {
        messageIDs.add(id);
        messageHashes.add(hash);
        recipients.add(recipient);
        allMessages.add(text);
        flags.add(flag);

        if (flag.equals(SENT)) {
            sentMessages.add(text);
        } else if (flag.equals(STORED)) {
            storedMessages.add(text);
        } else if (flag.equals(DISREGARD)) {
            disregardedMessages.add(text);
        }
        return hash;
    }

    /**
     * Loads stored messages read from the JSON file into the arrays.
     * Each record is {messageID, messageHash, recipient, message}. Records whose
     * ID is already in the arrays are skipped so nothing is added twice.
     */
    public void loadStoredMessages(ArrayList<String[]> records) {
        for (String[] record : records) {
            if (!messageIDs.contains(record[0])) {
                addMessage(record[0], record[1], record[2], record[3], STORED);
            }
        }
    }

    /** Random ten-digit message ID. */
    public String generateMessageID() {
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    /**
     * First two digits of the ID : message number : first word + last word,
     * in capitals. Punctuation is stripped from the words so
     * "Hi Mike, ... tonight?" gives 00:0:HITONIGHT.
     */
    public String createMessageHash(String id, int messageNumber, String text) {
        String[] words = text.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (id.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // ------------------------------------------------------------------
    // 2a. Sender and recipient of all stored messages
    // ------------------------------------------------------------------
    public String displaySendersAndRecipients() {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(STORED)) {
                output.append("Sender: ").append(sender)
                      .append(" | Recipient: ").append(recipients.get(i)).append("\n");
            }
        }
        return output.length() == 0 ? "No stored messages." : output.toString();
    }

    // ------------------------------------------------------------------
    // 2b. Longest stored message
    // ------------------------------------------------------------------
    public String getLongestStoredMessage() {
        String longest = "";
        for (String message : storedMessages) {
            if (message.length() > longest.length()) {
                longest = message;
            }
        }
        return longest.isEmpty() ? "No stored messages." : longest;
    }

    // ------------------------------------------------------------------
    // 2c. Search by message ID
    // ------------------------------------------------------------------
    public String getMessageByID(String id) {
        int index = messageIDs.indexOf(id);
        return index == -1 ? "Message ID not found." : allMessages.get(index);
    }

    public String getRecipientByID(String id) {
        int index = messageIDs.indexOf(id);
        return index == -1 ? "Message ID not found." : recipients.get(index);
    }

    // ------------------------------------------------------------------
    // 2d. All sent or stored messages for one recipient
    // ------------------------------------------------------------------
    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++) {
            boolean sentOrStored = flags.get(i).equals(SENT) || flags.get(i).equals(STORED);
            if (sentOrStored && recipients.get(i).equals(recipient)) {
                found.add(allMessages.get(i));
            }
        }
        return found;
    }

    // ------------------------------------------------------------------
    // 2e. Delete using the message hash
    // ------------------------------------------------------------------
    public String deleteMessageByHash(String hash) {
        int index = messageHashes.indexOf(hash);
        if (index == -1) {
            return "Message hash not found.";
        }
        String text = allMessages.get(index);
        String flag = flags.get(index);

        // remove from the category array first, then from the parallel arrays
        if (flag.equals(SENT)) {
            sentMessages.remove(text);
        } else if (flag.equals(STORED)) {
            storedMessages.remove(text);
        } else {
            disregardedMessages.remove(text);
        }
        messageIDs.remove(index);
        messageHashes.remove(index);
        recipients.remove(index);
        allMessages.remove(index);
        flags.remove(index);

        return "Message: \"" + text + "\" successfully deleted.";
    }

    // ------------------------------------------------------------------
    // 2f. Report of all messages with a given flag (Sent or Stored)
    // ------------------------------------------------------------------
    public String buildReport(String flag) {
        StringBuilder report = new StringBuilder("===== " + flag + " Messages Report =====\n");
        int count = 0;
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(flag)) {
                count++;
                report.append("Message ID:   ").append(messageIDs.get(i)).append("\n")
                      .append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                      .append("Sender:       ").append(sender).append("\n")
                      .append("Recipient:    ").append(recipients.get(i)).append("\n")
                      .append("Message:      ").append(allMessages.get(i)).append("\n")
                      .append("---------------------------------\n");
            }
        }
        if (count == 0) {
            report.append("No messages to report.\n");
        }
        return report.toString();
    }

    // ------------------------------------------------------------------
    // Menu option 4: "Stored Messages"
    // ------------------------------------------------------------------
    public void storedMessagesMenu(Scanner input) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("1) Display sender and recipient of all stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search messages for a recipient");
            System.out.println("5) Delete a message using its hash");
            System.out.println("6) Display report of all stored messages");
            System.out.println("7) Back to main menu");
            System.out.print("Choose an option: ");

            switch (input.nextLine().trim()) {
                case "1":
                    System.out.println(displaySendersAndRecipients());
                    break;
                case "2":
                    System.out.println("Longest stored message: " + getLongestStoredMessage());
                    break;
                case "3":
                    System.out.print("Enter message ID: ");
                    String id = input.nextLine().trim();
                    System.out.println("Recipient: " + getRecipientByID(id));
                    System.out.println("Message: " + getMessageByID(id));
                    break;
                case "4":
                    System.out.print("Enter recipient number: ");
                    ArrayList<String> found = searchByRecipient(input.nextLine().trim());
                    if (found.isEmpty()) {
                        System.out.println("No messages found for that recipient.");
                    }
                    for (String message : found) {
                        System.out.println("- " + message);
                    }
                    break;
                case "5":
                    System.out.print("Enter message hash: ");
                    System.out.println(deleteMessageByHash(input.nextLine().trim().toUpperCase()));
                    break;
                case "6":
                    System.out.println(buildReport(STORED));
                    break;
                case "7":
                    back = true;
                    break;
                default:
                    System.out.println("Invalid option, please choose 1-7.");
            }
        }
    }

    // ------------------------------------------------------------------
    // Getters (used by the unit tests)
    // ------------------------------------------------------------------
    public ArrayList<String> getSentMessages() { return sentMessages; }
    public ArrayList<String> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<String> getStoredMessages() { return storedMessages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
}
