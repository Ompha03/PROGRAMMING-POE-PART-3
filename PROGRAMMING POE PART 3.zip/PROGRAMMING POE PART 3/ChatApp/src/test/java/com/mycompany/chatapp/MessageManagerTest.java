/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Part 3 unit tests, populated with the five test messages from the spec. */
public class MessageManagerTest {

    private static final String MSG1 = "Did you get the cake?";
    private static final String MSG2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String MSG3 = "Yohoooo, I am at your gate.";
    private static final String MSG4 = "It is dinner time!";
    private static final String MSG5 = "Ok, I am leaving without you.";

    private MessageManager manager;

    @BeforeEach
    public void setUp() {
        manager = new MessageManager("Tester");
        manager.addMessage("1000000001", "+27834557896", MSG1, MessageManager.SENT);
        manager.addMessage("2000000002", "+27838884567", MSG2, MessageManager.STORED);
        manager.addMessage("3000000003", "+27834484567", MSG3, MessageManager.DISREGARD);
        // Test message 4 is the developer entry: its ID is 0838884567
        manager.addMessage("0838884567", "0838884567", MSG4, MessageManager.SENT);
        manager.addMessage("5000000005", "+27838884567", MSG5, MessageManager.STORED);
    }

    @Test
    public void sentMessagesArrayCorrectlyPopulated() {
        assertEquals(Arrays.asList(MSG1, MSG4), manager.getSentMessages());
    }

    @Test
    public void disregardedAndStoredArraysCorrectlyPopulated() {
        assertEquals(Arrays.asList(MSG3), manager.getDisregardedMessages());
        assertEquals(Arrays.asList(MSG2, MSG5), manager.getStoredMessages());
    }

    @Test
    public void hashAndIdArraysPopulated() {
        assertEquals(5, manager.getMessageHashes().size());
        assertEquals(5, manager.getMessageIDs().size());
    }

    @Test
    public void messageHashIsCorrect() {
        assertEquals("00:0:HITONIGHT", manager.createMessageHash("0012345678", 0,
                "Hi Mike, can you join us for dinner tonight?"));
        assertEquals("10:0:DIDCAKE", manager.getMessageHashes().get(0));
    }

    @Test
    public void displayLongestMessage() {
        assertEquals(MSG2, manager.getLongestStoredMessage());
    }

    @Test
    public void searchForMessageID() {
        assertEquals(MSG4, manager.getMessageByID("0838884567"));
        assertEquals("0838884567", manager.getRecipientByID("0838884567"));
    }

    @Test
    public void searchForUnknownMessageID() {
        assertEquals("Message ID not found.", manager.getMessageByID("9999999999"));
    }

    @Test
    public void searchMessagesForRecipient() {
        ArrayList<String> expected = new ArrayList<>(Arrays.asList(MSG2, MSG5));
        assertEquals(expected, manager.searchByRecipient("+27838884567"));
    }

    @Test
    public void deleteMessageUsingHash() {
        String hash = manager.getMessageHashes().get(1); // test message 2
        assertEquals("Message: \"" + MSG2 + "\" successfully deleted.",
                manager.deleteMessageByHash(hash));
        assertFalse(manager.getStoredMessages().contains(MSG2));
        assertEquals(4, manager.getMessageHashes().size());
    }

    @Test
    public void deleteWithUnknownHash() {
        assertEquals("Message hash not found.", manager.deleteMessageByHash("XX:9:NOPE"));
    }

    @Test
    public void addMessageKeepsSuppliedHash() {
        manager.addMessage("6000000006", "60:0:HELLOBYE", "+27830000001", "Hello and bye", MessageManager.SENT);
        assertTrue(manager.getMessageHashes().contains("60:0:HELLOBYE"));
        assertEquals(6, manager.getMessageIDs().size());
    }

    @Test
    public void loadStoredMessagesSkipsDuplicates() {
        ArrayList<String[]> records = new ArrayList<>();
        records.add(new String[]{"5000000005", "50:4:OKYOU", "+27838884567", MSG5}); // already loaded
        records.add(new String[]{"7000000007", "70:0:SEEYOU", "+27830000000", "See you"});
        manager.loadStoredMessages(records);
        assertEquals(Arrays.asList(MSG2, MSG5, "See you"), manager.getStoredMessages());
    }

    @Test
    public void reportListsSentMessages() {
        String report = manager.buildReport(MessageManager.SENT);
        assertTrue(report.contains(manager.getMessageHashes().get(0)));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains(MSG1));
        assertTrue(report.contains(MSG4));
        assertFalse(report.contains(MSG2));
    }
}